<?php include '../header.php'; ?>

<style>
    body {
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
    }

    table {
        color: #ddd;
        box-shadow: 5px 20px 50px #000;
        text-align: center;
    }

    th {
        text-align: center;
    }

    .table-striped {
        >tbody>tr:nth-of-type(odd) {
            background-color: #95959b;
        }
    }

    .table>tbody>tr>th,
    .table>tbody>tr>td {
        border-top: 0px;
    }

    i {
        margin-right: 35px;
    }

    .no-bottom-border td {
        border: none;
    }

    .table-view {
        height: 100vh;
    }
</style>
<div class="container table-view">
    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Id</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Action</th>

            </tr>
        </thead>
        <tbody>
            <tr class="no-bottom-border"">
                <th scope=" row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>
            </tr>
            <tr class="no-bottom-border">
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>


            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
                <td><i class="fa fa-eye"></i><i class="fa fa-pencil"></i><i class="fa fa-trash"></i></td>

            </tr>
        </tbody>
    </table>
</div>