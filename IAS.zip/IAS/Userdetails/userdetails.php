<?php include '../header.php'; ?>

<style>
    body {
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
    }

    .userdetails {
        height: 90vh;
        width: 100%;
        box-shadow: 5px 20px 50px #000;

        /* margin-left: 40% */
    }

    .userdetail-alignment {
        display: flex;
        flex-wrap: wrap;
        align-content: center;
        justify-content: center;
        flex-direction: column;
    }

    .userdetails label {
        color: #ddd;
        padding: 15px 0px;
    }

    .box-sha {
        width: 50%;
        border: 1px solid white;
        margin-left: 40%;
        position: relative;
    }
   
.fill:hover {
    color: #ddd;
}

.fill:before {
    content: "";
    position: absolute;
    background: #6d44b8;
    bottom: 0;
    left: 0;
    right: 0;
    top: 100%;
    z-index: -1;
    -webkit-transition: top 0.09s ease-in;
}

.fill:hover:before {
    top: 0;
}

.view-more {
    position: relative;
    left: 90%;
    padding: 10px 20px;
    border-radius: 40px;
    border: 1px solid #000000;
    position: relative;
    color: #ddd;
    background: #573b8a !important;
    text-transform: uppercase;
    outline: 0;
    overflow: hidden;
    background: none;
    z-index: 1;
    cursor: pointer;
 
}
.userdetails img{
    height: 150px !important;
    width: 150px !important;
    position: relative;
    top: 30%;
    left: 10%;
    border-radius: 20px;
}
</style>
<div class="container">
    <div class='userdetails'>
        <button class='view-more fill'> Back</button>
        <img src="" alt="" >
        <div class='row box-sha'>
            <div class='col-md-6 userdetail-alignment'>
                <label for="name">Username</label>
                <label for="email">Email</label>
                <label for="password">Password</label>
                <label for="phonenumber">PhoneNumber</label>
                <label for="address">Address</label>
                <label for="gender">Gender</label>

            </div>

            <div class='col-md-6 userdetail-alignment'>
                <label for="name">Username</label>
                <label for="email">Email</label>
                <label for="password">Password</label>
                <label for="phonenumber">PhoneNumber</label>
                <label for="address">Address</label>
                <label for="gender">Gender</label>
            </div>
        </div>
    </div>
</div>