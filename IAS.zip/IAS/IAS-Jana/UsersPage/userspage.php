<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='test';
$request = $_POST['request'];
$users = [];
if($request=="view_all_users"){
    $conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            array_push($users,$row);
        }
        echo json_encode(["code"=>"200","users"=>$users]);
        $conn->close();
        exit;
    }
    else{
        echo json_encode(["code"=>"300"]);
        $conn->close();
        exit;
    }

}
if($request=="edit_users"){
    $users = [];
    $conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
    $id=$_POST["id"];
    $sql = "SELECT * FROM users where sno='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            array_push($users,$row);
        }
        echo json_encode(["code"=>"200","users"=>$users]);
        $conn->close();
        exit;
    }

}
if($request=="view_users"){
    $users = [];
    $conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
    $id=$_POST["id"];
    $sql = "SELECT * FROM users where sno='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            array_push($users,$row);
        }
        echo json_encode(["code"=>"200","users"=>$users]);
        $conn->close();
        exit;
    }

}
if($request=="update_users"){
    $conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
    $id=$_POST["id"];
    $username = $_POST["username"];
    $phone_number = $_POST["phone_number"];
    $gender = $_POST["gender"];
    $address = $_POST["address"];
    $sql = "UPDATE users set username='$username',phone_number='$phone_number',gender='$gender',address='$address' where sno='$id'";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["code"=>"200","msg"=>"Updated"]);
        $conn->close();
        exit;
    }

}
if($request=="delete_users"){
    $conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
    $id=$_POST["id"];
    $sql = "DELETE FROM users where sno='$id'";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["code"=>"200","msg"=>"Deleted"]);
        $conn->close();
        exit;
    }

}
?>