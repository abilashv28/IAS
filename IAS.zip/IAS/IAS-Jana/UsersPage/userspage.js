document.getElementsByTagName("html")[0].style.height = "100%";
document.getElementsByTagName("body")[0].style.background = "linear-gradient(#141e30, #243b55)";
$("#back").click(function(){
$("#individual_page").addClass("hidden");
$("#users_list_page").removeClass("hidden");
});
$("#view_users").click(function(){
    $("#users_list").text("");
    $.ajax({
        type: "POST",
        url: "http://localhost/IAS-Jana/UsersPage/userspage.php",
        data: {request:"view_all_users"},
        success: function(result){
            result = JSON.parse(result);    
            if(result.code=="200"){

                let d = "<table class='table table-striped'><thead><tr><th>Sno</th><th>Username</th><th>View</th><th>Edit</th><th>Delete</th></tr></thead>";
                for(let i=0;i<result.users.length;i++){
                    d+="<tr><td>"+(i+1)+"</td><td>"+result.users[i].username+"</td><td id='"+result.users[i].sno+"' onclick='viewuser(this)'><i class='fa fa-eye' style='font-size:22px'></i></td><td id='"+result.users[i].sno+"' onclick='edituser(this)'><i class='fa fa-edit' style='font-size:22px'></i></td><td id='"+result.users[i].sno+"' onclick='deleteuser(this)'><i class='fa fa-trash-o' style='font-size:22px'></i></td></tr>";
                }
                d+="</table>";
                $("#users_list").append(d);
            }
            else{
                $("#users_list").append("<p style='color:white'>No Users Avaliable</p>");
            }
    }});
});

$("#update").click(function(){
    $.ajax({
        type: "POST",
        url: "http://localhost/IAS-Jana/UsersPage/userspage.php",
        data: {request:"update_users",id: user_id,username:$("#username").val(),phone_number:$("#phone_number").val(), gender: $("#gender").val(), address:$("#address").val()},
        success: function(result){
            result = JSON.parse(result);    
            if(result.code=="200"){
                $("#close").click();

            }
    }});
});

function viewuser(e){
    $.ajax({
        type: "POST",
        url: "http://localhost/IAS-Jana/UsersPage/userspage.php",
        data: {request:"view_users",id:e.id},
        success: function(result){
            result = JSON.parse(result);    
            if(result.code=="200"){
                $("#users_list_page").addClass("hidden");
                $("#individual_page").removeClass("hidden");
                $("#view_username").text(result.users[0].username);
                $("#view_phone_number").text(result.users[0].phone_number);
                $("#view_gender").text(result.users[0].gender);
                $("#view_address").text(result.users[0].address);
                $("#view_photo").text('');
                let a = result.users[0].photo.replace("%3A",":");
                a = a.split("/");
                a = a[3]+"/"+a[4]+"/"+a[5];
                $("#view_photo").append('<img src="/'+a+'" height="300px" widhth="300px">')
            }
    }});
}
function edituser(e){
    $.ajax({
        type: "POST",
        url: "http://localhost/IAS-Jana/UsersPage/userspage.php",
        data: {request:"edit_users",id: e.id},
        success: function(result){
            result = JSON.parse(result);    
            if(result.code=="200"){
                user_id=e.id;
                $("#username").val(result.users[0].username);
                $("#phone_number").val(result.users[0].phone_number);
                $("#gender").val(result.users[0].gender);
                $("#address").val(result.users[0].address);
                $("#modal").click();
            }
    }});
}
function deleteuser(e){
    $.ajax({
        type: "POST",
        url: "http://localhost/IAS-Jana/UsersPage/userspage.php",
        data: {request:"delete_users",id: e.id},
        success: function(result){
            result = JSON.parse(result);    
            if(result.code=="200"){
                $("#view_users").click();
            }
    }});
}