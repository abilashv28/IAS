<html>
<head>
  <title>Register Page</title>
  <link rel="icon" href="/Users/Vj Jana/Desktop/favicon.png" type="image/x-icon">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <link rel="stylesheet" href="../style.css">
<style>
  img{
    position: relative;
    left: -169px;
}
    table th{
        color:white;
    }
    #individual_page{
      color: #03e9f4 !important;
    }
    table tr{
        color: #03e9f4 !important;
    }
    .table-striped>tbody>tr:nth-of-type(odd){
        background-color: transparent;
    }
    i{
        cursor:pointer;
    }
    .hidden{
      display:none;
    }
    #individual_page{
      position: relative !important;
      left: 15%!important;
      top: 2%!important;

    }
    #back{
      right: 114px;
    position: relative;
    top: 0px;
    color: black;
    font-size: 22px;
    }
    #individual_page > div > div{
      padding: 12px;
    }
    a{
      position: relative;
    top: -25px;
      color: white;
      float: right;
      padding: 3px;
      font-size: 17px;
    }
</style>
</head>
<body>
  <div id="users_list_page">
    <h2 style="color:white;">Users Page</h2>
    <a href="http://localhost/IAS-Jana/register/">Register</a>
    <a href="http://localhost/IAS-Jana/Login/">Login</a>
    <div id="users_list" class="container"></div>
 <button id="view_users" style="display:none;"></button>

 <div class="container">
  <!-- Trigger the modal with a button -->
  <button id="modal" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="display:none;">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button id="close" type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <h2>Update User Detail</h2>
            <label for="">Username: </label>
          <input type="text" id="username" readonly> <br>
          <label for="">Phone Number: </label>
          <input type="text" id="phone_number"><br>
          <label for="">Gender: </label>
          <input type="text" id="gender"><br>
          <label for="">Address: </label>
          <input type="text" id="address"> <br>
          <button id="update">Update</button>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
  </div>

  <div id="individual_page" class="hidden">
    <button id="back">Go Back </button>
    <h1>Users Individual Page</h1>
    <div class="conatiner">
      <div class="row">
        <div class="col">
          Username
        </div>
        <div class="col" id="view_username">
        </div>
      </div>
      <div class="row">
        <div class="col">
          Phone Number
        </div>
        <div class="col" id="view_phone_number">
        </div>
      </div>
      <div class="row">
        <div class="col">
          Gender
        </div>
        <div class="col" id="view_gender">
        </div>
      </div>
      <div class="row">
        <div class="col">
          Address
        </div>
        <div class="col" id="view_address">
        </div>
      </div>
      <div class="row">
        <div class="col">
          Image
        </div>
        <div class="col" id="view_photo">
        </div>
      </div>
    </div>
  </div>
</body>
<script src="./userspage.js"></script>
<script>
  var user_id;
    $("#view_users").click();
</script>
</html>