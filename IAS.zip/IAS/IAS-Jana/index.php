<?php
header("Location: http://localhost/IAS/IAS-Jana/Login/"); 
?>