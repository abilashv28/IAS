<html>
<head>
  <title>Register Page</title>
  <link rel="icon" href="/Users/Vj Jana/Desktop/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <link rel="stylesheet" href="../style.css">

</head>
<body>
  <div onClick="WhichButton()" class="login-box">
    <h2>Login</h2>
    <form>
      <div class="user-box">
        <input onfocus="Focuss('useridd')" type="text" name="userid" id='userid'>
        <label id='useridd'>Username</label>
      </div>
      <div class="user-box">
        <input onfocus="Focuss('psww')" type="password" name="psw" id='psw'>
        <label id='psww'>Password</label>
      </div>
      <div class='status-msg' id='loginstatus'></div>
      <a onClick="Loginn()">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        Login
      </a>
    </form>
  </div>
  <script>
    const Loginn = ()=>{
        if($("#userid").val()!="" && $("#psw").val()!=""){
            $.ajax({
                type: "POST",
                url: "http://localhost/IAS-Jana/Login/login.php",
                data: {username: $("#userid").val(), password: $("#psw").val() },
                success: function(result){
                    result = JSON.parse(result);    
                    if(result.code=="200"){
                      $("#loginstatus").text(result.msg);
                      window.location.href = "http://localhost/IAS-Jana/UsersPage/";
                    }  
                    else if(result.code=="300"){
                      $("#loginstatus").text(result.msg);
                    } 
                    else{
                      $("#loginstatus").text(result.msg);
                    }
            }});
        }
        else{
            if($("#userid").val()==""){$("#loginstatus").text('Username Missing');}
            else{if($("#psw").val()==""){$("#loginstatus").text('Password Missing');}}
        }
    }
    document.getElementsByTagName("html")[0].style.height = "100%";
    document.getElementsByTagName("body")[0].style.background = "linear-gradient(#141e30, #243b55)";
    const Focuss = (id)=>{
      document.querySelector("#"+id).classList="focus-input";
    }
    const WhichButton = ()=> {
    if((document.getElementById("userid") === document.activeElement)===false)  {
        if(document.getElementById("userid").value===""){
        document.querySelector("#useridd").classList.remove("focus-input")
    }
    }
    if((document.getElementById("psw") === document.activeElement)==false)  {
        if(document.getElementById("psw").value===""){
        document.querySelector("#psww").classList.remove("focus-input")
        }
    }
}
  </script>
</body>
</html>