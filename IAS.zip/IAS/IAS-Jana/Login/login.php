<?php
session_start();
$code=200;
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='test';

$username = $_POST["username"];
$password = $_POST["password"];

$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM users where username='$username' and password='$password' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo json_encode(['code'=>200, 'msg'=>'Login Successfully']);
    $conn->close(); 
    exit;
}
else{
    $sql5 = "SELECT * FROM users where username='$username'";
    $result1 = $conn->query($sql5);
    if ($result1->num_rows > 0) {
        echo json_encode(['code'=>400, 'msg'=>"Wrong Password"]);
        $conn->close(); 
        exit;
    }
    else{
        echo json_encode(['code'=>300, 'msg'=>"Invalid Username"]);
        $conn->close(); 
        exit;
    }
}

?>