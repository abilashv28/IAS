<html>
<head>
  <title>Register Page</title>
  <link rel="icon" href="favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<link rel="stylesheet" href="../style.css">


</head>
<body>
  <div onClick="WhichButton()" class="login-box">
    <h2>Login</h2>
    <form>
      <div class="user-box">
        <input onfocus="Focuss('usernamee')" type="text" name="username" id='username'>
        <label id='usernamee'>Username</label>
      </div>
      <div class="user-box">
        <input onfocus="Focuss('phone_numberr')" type="text" name="userid" id='phone_number'>
        <label id='phone_numberr'>Phone number</label>
      </div>
      <div class="user-box">
        <input onfocus="Focuss('genderr')" type="radio" name="userid" id='male'>
        <label id='malee'>Male</label>
        <input onfocus="Focuss('genderr')" type="radio" name="userid" id='female'>
        <label id='femalee'>Female</label>
        <label id='genderr'>Gender</label>
      </div>
      <div class="user-box">
        <input onfocus="Focuss('addresss')" type="text" name="userid" id='address'>
        <label id='addresss'>Address</label>
      </div>
      <div class="user-box">
        <input onchange="handleimgupload(this)" onfocus="Focuss('photoo')" accept="image/*" type="file" name="userid" id='photo'>
        <label id='photoo'>Photo</label>
      </div>
      <div class="user-box">
        <input onfocus="Focuss('passwordd')" type="password" name="psw" id='password'>
        <label id='passwordd'>Password</label>
      </div>
      <div class='status-msg' id='loginstatus'></div>
      <a onClick="Registerr()">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        Register
      </a>
    </form>
  </div>
  <script>
    $("#female").click(function(){
      if(document.getElementById("male").classList.contains("selected")==true){
        document.getElementById("female").classList.remove("selected");
      }
      else{
        document.getElementById("male").classList="selected";
        document.getElementById("female").classList.remove("selected");
      }
    });
    $("#male").click(function(){
      if(document.getElementById("female").classList.contains("selected")==true){
        document.getElementById("male").classList.remove("selected");
      }
      else{
        document.getElementById("female").classList="selected";
        document.getElementById("male").classList.remove("selected");
      }
    });
    document.getElementsByTagName("html")[0].style.height = "100%";
    document.getElementsByTagName("body")[0].style.background = "linear-gradient(#141e30, #243b55)";
    var img_path;
    function handleimgupload(e){
      var tmpPath;
    var formData;
    var file;
      file = e.files[0];
      if (file) {
      tempPath = URL.createObjectURL(file);
      formData = new FormData();
      formData.append('file', file);
      imagee = formData;
      }
      $.ajax({
        contentType: false,
         cache: false,
        type: "POST",
        url: "http://localhost/IAS-Jana/Register/img_upload.php",
        processData: false, 
        data: formData,
        success: function(result){
            result = JSON.parse(result);  
            if(result.code=="200"){
              img_path = result.photo_path;
            }  
                
        }});
    }
    const Registerr = ()=>{
      if($("#username").val()==""){
        $("#loginstatus").text("Username Missing");
      }
      else if($("#phone_number").val()==""){
        $("#loginstatus").text("Phone Number Missing");
      }
      else if($("#male").hasClass("selected")==false && $("#female").hasClass("selected")==false){
        $("#loginstatus").text("Gender Missing");
      }
      else if($("#address").val()==""){
        $("#loginstatus").text("Address Missing");
      }
      else if($("#photo").val()==""){
        $("#loginstatus").text("Photo Missing");
      }
      else if($("#password").val()==""){
        $("#loginstatus").text("Password Missing");
      }
      else{ 
        console.log(img_path);
        $("#loginstatus").text('');
        let gender='';
        if($("#male").hasClass("selected")==false){
          gender="Female";
        }
        else{
          gender = "Male";
        }
        $.ajax({
                type: "POST",
                url: "http://localhost/IAS-Jana/Register/register.php",
                data: {username: $("#username").val(), password: $("#password").val(),address: $("#address").val(),phone_number:$("#phone_number").val(),gender:gender,photo:escape(img_path)},
                success: function(result){
                    result = JSON.parse(result);  
                    if(result.code=="200"){
                      $("#loginstatus").text(result.msg);
                      window.location.href = "/IAS-Jana/Login";
                    }  
                    else{
                      $("#loginstatus").text(result.msg);
                    }
                    
            }});
      }
    }

    const Focuss = (id)=>{
      document.querySelector("#"+id).classList="focus-input";
    }
    const WhichButton = ()=> {
    if((document.getElementById("username") === document.activeElement)===false)  {
        if(document.getElementById("username").value===""){
        document.querySelector("#usernamee").classList.remove("focus-input")
    }
    }
    if((document.getElementById("phone_number") === document.activeElement)===false)  {
        if(document.getElementById("phone_number").value===""){
        document.querySelector("#phone_numberr").classList.remove("focus-input")
    }
    }
    
    if((document.getElementById("address") === document.activeElement)===false)  {
        if(document.getElementById("address").value===""){
        document.querySelector("#addresss").classList.remove("focus-input")
    }
    }
    if((document.getElementById("photo") === document.activeElement)===false)  {
        if(document.getElementById("photo").value===""){
        document.querySelector("#photoo").classList.remove("focus-input")
    }
    }
    if((document.getElementById("password") === document.activeElement)==false)  {
        if(document.getElementById("password").value===""){
        document.querySelector("#passwordd").classList.remove("focus-input")
        }
    }
}
  </script>
</body>
</html>