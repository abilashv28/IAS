<?php
session_start();
$code=200;
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='test';

$username = $_POST["username"];
$phone_number = $_POST["phone_number"];
$gender = $_POST["gender"];
$address = $_POST["address"];
$photo = $_POST["photo"];
$password = $_POST["password"];

$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM users where username='$username'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo json_encode(['code'=>300, 'msg'=>'Username Already Exist']);
    $conn->close(); 
    exit;
}
else{
    $sql8 = "INSERT INTO users(username,phone_number,gender,address,photo,password) values('$username','$phone_number','$gender','$address','$photo','$password')";
    if ($conn->query($sql8)==TRUE){
        $lastInsertedID = mysqli_insert_id($conn);
        echo json_encode(['code'=>200, 'msg'=>'User Added Successfully']);
        $conn->close(); 
        exit;
    }  
    else{
        echo json_encode(['code'=>400, 'msg'=>"f"]);
        $conn->close(); 
        exit;
    }

}



?>