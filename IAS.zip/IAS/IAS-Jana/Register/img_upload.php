<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
function imgupload($root){
    if(isset($_FILES['file']))
    {
        $filepresent="true";
        $img = $_FILES['file']['name'];
        $tmp = $_FILES['file']['tmp_name'];
        //$tmp = $tmp.".webm";

        $imgSize = $_FILES['file']['size'];    

        $img = str_replace(' ', '-', $img);
        $img = preg_replace('/[^A-Za-z0-9.\-]/', '', $img);


        // get uploaded file's extension
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));

        // can upload same image using rand function
        $final_image = rand(1000,1000000)."-".$img;


        $current_time = new DateTime();
        $today_folder=date_format($current_time,"Y-m-d-H-i-s");
        $newpath=$root."/IAS-Jana/Images/";

        //if (!file_exists('path/to/directory'))
        if (!file_exists($newpath))
        {
                mkdir($newpath, 0777, true);
        }
        $path=$newpath;
        $vdpath = $path;
        $path = $path.strtolower($final_image); 
        $vdpath=$vdpath.$final_image;
        $today = Date("F j, Y, g:i a");
        $pathh = $path;
        if(move_uploaded_file($tmp,$path)) 
        {
            $api_user='1';//hardcode $_SESSION['user_id']
            $path=$root.'/IAS-Jana/Images/';
            $path = strtolower($path); 


            $path=substr($path,14);

            $path="https://".$path;
            echo json_encode(["code"=>"200","photo_path"=>$pathh]);
            exit;
        }

    }
}
imgupload($root);
?>