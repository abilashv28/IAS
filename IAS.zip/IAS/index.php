<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title> Sign up / Login Form</title>
	<link rel="stylesheet" href="./style.css">
	<!-- Latest compiled and minified CSS -->

</head>

<body>
	<!-- partial:index.partial.html -->
	<!DOCTYPE html>
	<html>

	<head>
		<title>Slide Navbar</title>
		<link rel="stylesheet" type="text/css" href="slide navbar style.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
			integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
	</head>

	<body>
		<div class="main">
			<input type="checkbox" id="chk" aria-hidden="true">

			<div class="signup">
				<form>
					<div class='signuptxt'>
						<label for="chk" aria-hidden="true">Sign up</label>

					</div>
					<div class='row fields'>
						<div class='col-md-6'>
							<div class="form-group">
								<input type="text" class="form-control" name="txt" placeholder="User name" required="">
							</div>
							<div class="form-group">
								<input type="password" class="form-control" name="pswd" placeholder="Password"
									required="">
							</div>

							<div class="form-group">
								<input type="number" class="form-control" name="num" placeholder="Phone Number"
									required="">

							</div>
							<div class="form-group">
								<input type="textarea" class="form-control" name="txt" placeholder="Address"
									required="">
							</div>



						</div>
						<div class='col-md-6'>
							<div class="form-group">
								<input type="email" class="form-control" name="email" placeholder="Email" required="">
							</div>

							<div class="form-group">
								<input type="password" class="form-control" name="pswd" placeholder="Confirm Password"
									required="">
							</div>

							<div class="form-group">
								<input class="form-control" onchange="handleimgupload(this)" onfocus="Focuss('photoo')"
									accept="image/*" type="file" name="userid" id='photo'>
							</div>
							<div class="form-group">
								<div class=''>
									<h2 for="">Gender</h2>
								</div>
								<div class='row gender'>
									<div class='col-md-6'>
										<label for="">Male</label>
									</div>
									<div class='col-md-6'>
										<input type="radio" name="gender" class="gender" id="">
									</div>
								</div>
								<div class='row gender'>
									<div class='col-md-6'>
										<label for="">Female</label>
									</div>
									<div class='col-md-6'>
										<input type="radio" name="gender" class="gender" id="">
									</div>
								</div>
							</div>

						</div>
					</div>

					<div class="btnindex">
						<button>Sign up</button>
					</div>
				</form>
			</div>

			<div class="login">
				<form>
					<div class='logintxt'>
						<label for="chk" aria-hidden="true">Login</label>
					</div>
					<div class='loginfields'>
						<input type="email" name="email" placeholder="Email" required="">
						<input type="password" name="pswd" placeholder="Password" required="">
						<div class="btnindex">
							<button>Login</button>
						</div>
					</div>

				</form>
			</div>
		</div>
	</body>

	</html>
	<!-- partial -->

</body>

</html>